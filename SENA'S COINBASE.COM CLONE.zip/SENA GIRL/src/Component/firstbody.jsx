import React from 'react'
import blogo1 from './../Asset/blogo1.png'

const Firstbody = () => {
    // Image used to simplify the cloning
    return (
        <div className='body1'>
            <img className='bod_img' src={blogo1} alt='coinbase body page' />
        </div>

    )
}

export default Firstbody
